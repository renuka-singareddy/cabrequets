package com.cg.DAO;

import com.cg.Bean.Bean;
import com.cg.EXCEPTION.MyException;

public interface IDao 
{

	int addCabDetails(Bean bean) throws MyException, Exception;
	Bean viewDonorDetails(int reqId) throws MyException;
}
