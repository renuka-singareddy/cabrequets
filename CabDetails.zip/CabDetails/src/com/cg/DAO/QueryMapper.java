package com.cg.DAO;
public interface QueryMapper 
{
	public static final String VIEW_CAB_DETAILS_QUERY="SELECT uname,phonenumber,address,pincode,status,cabnumber FROM cabdetails WHERE  reqId=?";
	public static final String INSERT_QUERY="INSERT INTO cabdetails VALUES(reqId_sequence.NEXTVAL,?,?,?,?,?,?)";
	public static final String REQUISITIONID_QUERY_SEQUENCE="SELECT reqId_sequence.CURRVAL FROM DUAL";
}
