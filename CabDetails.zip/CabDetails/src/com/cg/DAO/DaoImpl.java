package com.cg.DAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.cg.Bean.Bean;
import com.cg.EXCEPTION.MyException;
import com.cg.UTIL.DBConnection;
public class DaoImpl implements IDao
{
	@Override
	public int addCabDetails(Bean bean) throws Exception
	{
		Connection connection = DBConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		int reqId=0;
		boolean valid = false;
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);
			preparedStatement.setString(1,bean.getUname());			
			preparedStatement.setLong(2,bean.getPhoneNumber());
			preparedStatement.setString(3,bean.getAddress());
			preparedStatement.setLong(4,bean.getPinCode());	
			preparedStatement.setString(5,bean.getCabNumber());
			preparedStatement.setString(6,bean.getStatus());
			queryResult=preparedStatement.executeUpdate();
//			preparedStatement = connection.prepareStatement(QueryMapper.REQUISITIONID_QUERY_SEQUENCE);
//			resultSet=preparedStatement.executeQuery();
			if(queryResult > 0)
			{
				valid = true;
				preparedStatement=connection.prepareStatement(QueryMapper.REQUISITIONID_QUERY_SEQUENCE);
				resultSet = preparedStatement.executeQuery();
				resultSet.next();
				reqId=resultSet.getInt(1);
					
			}
			else{
				valid = false;
				throw new MyException();
			}
			
		}
		catch(SQLException sqlException)
		{
			throw new Exception("Tehnical problem occured refer log");
		}
		finally
		{
			
			
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new MyException();

			}
		}
		return reqId;
	}
	@Override
	public Bean viewDonorDetails(int reqId) throws MyException 
	{
		Connection connection=DBConnection.getInstance().getConnection();
        PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		Bean bean=null;
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_CAB_DETAILS_QUERY);
			preparedStatement.setInt(1,reqId);
			resultset=preparedStatement.executeQuery();
			if(resultset.next())
			{
				bean = new Bean();
				bean.setUname(resultset.getString(1));
				bean.setPhoneNumber(resultset.getLong(2));
				bean.setAddress(resultset.getString(3));
				bean.setPinCode(resultset.getLong(4));
				bean.setCabNumber(resultset.getString(5));
				bean.setStatus(resultset.getString(5));
			}
		}
		catch(Exception e)
		{
			throw new MyException();
		}
		finally
		{
			try 
			{
				resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				throw new MyException("Error in closing db connection");

			}
		}
		return bean;
		
	}
	}

