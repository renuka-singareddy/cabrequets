package com.cg.Bean;
public class Bean 
{
	private String uname;
	private Long phoneNumber;
	private String address;
	private Long pinCode;
	private String status;
	private String cabNumber;
	private int reqId;
	public int getReqId() {
		return reqId;
	}
	public void setReqId(int reqId) {
		this.reqId = reqId;
	}
	public String getUname()
	{
		return uname;
	}
	public void setUname(String uname)
	{
		this.uname = uname;
	}
	public Long getPhoneNumber()
	{
		return phoneNumber;
	}
	public void setPhoneNumber(Long phoneNumber) 
	{
		this.phoneNumber = phoneNumber;
	}
	public String getAddress() 
	{
		return address;
	}
	public void setAddress(String address) 
	{
		this.address = address;
	}
	public Long getPinCode()
	{
		return pinCode;
	}
	public void setPinCode(Long pinCode)
	{
		this.pinCode = pinCode;
	}
	public String getStatus()
	{
		return status;
	}
	public void setStatus(String status)
	{
		this.status = status;
	}
	public String getCabNumber() 
	{
		return cabNumber;
	}
	public void setCabNumber(String cabNumber)
	{
		this.cabNumber = cabNumber;
	}
	
	
	
}
