package com.cg.Service;
import com.cg.Bean.Bean;
import com.cg.DAO.DaoImpl;
import com.cg.DAO.IDao;
import com.cg.EXCEPTION.MyException;
public class ServiceImpl implements IService 
{

	IDao dao=new DaoImpl();
	@Override
	public int addCabDetails(Bean bean) throws MyException, Exception
	{
		
		return dao.addCabDetails(bean);
		
	}
	@Override
	public Bean viewDonorDetails(int  reqId) throws MyException 
	{
		Bean bean=dao.viewDonorDetails(reqId);
		return bean;
	}

	
}
