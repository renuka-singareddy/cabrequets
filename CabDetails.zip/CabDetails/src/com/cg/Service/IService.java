package com.cg.Service;

import com.cg.Bean.Bean;
import com.cg.EXCEPTION.MyException;

public interface IService
{

	int addCabDetails(Bean bean) throws MyException, Exception;
	Bean viewDonorDetails(int reqId) throws MyException;

}
