package com.cg.PI;
import java.util.InputMismatchException;
import java.util.Scanner;
import com.cg.Bean.Bean;
import com.cg.EXCEPTION.MyException;
import com.cg.Service.IService;
import com.cg.Service.ServiceImpl;
public class Client 
{
	// Scanner sc = new Scanner(System.in);
	static  IService service=new ServiceImpl();
	
//	static int option=0;
	static String uname;
	static String address;
	static String status;
	static String cnumber;
	static Long mobilenumber;
	static Long pincode;
	
	public static void main(String[] args) throws Exception
	{
		Bean bean=new Bean();
		while(true) 
		{
			System.out.println("Cab Details");
			System.out.println("_______________________________\n");
            System.out.println("1.Add Cab Details");
			System.out.println("2.View Cab Details");
			System.out.println("3.Exit");
			System.out.println("Select an option:");

			 Scanner sc = new Scanner(System.in);
				int option = sc.nextInt();
				System.out.println(option);
				switch (option) 
				{
				case 1:
					int reqId=0;
						bean=populateBean();
						try
					    {
							int recqId = service.addCabDetails(bean);
							
								System.out.println("Cab Details  has been successfully registered");
							    System.out.println("Requisition  ID Is: "+ recqId);
							

						}
						catch(Exception e)
						{
							e.printStackTrace();
						}
						break;
					
				case 2:
					System.out.println("Enter numeric Requisition id:");
					reqId = sc.nextInt();
					bean=getCabDetails(reqId);
					if(bean!=null)
					{
							System.out.println("Name: "+bean.getUname());
							System.out.println("PhoneNumber: "+bean.getPhoneNumber());
							System.out.println("Pick Up Address:"+bean.getAddress());
					}
					else
					{
							System.err.println("There are no cab details associated with this id"+reqId);
					}
					break;
				case 3:
					System.out.print("Exit Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-3]");
				}
			
		}
	}
	private static Bean getCabDetails(int reqId) throws MyException
	{
		Bean bean=new Bean();
		bean=service.viewDonorDetails(reqId);
		service=null;
		return bean;
	}
	
	private static Bean populateBean()
	{
		Bean bean=new Bean();
		Scanner sc = new Scanner(System.in);
		System.out.println("\n Enter Cab Details");
        System.out.println("Enter User name: ");
        uname=sc.next();
        System.out.println("Enter Mobile Number: ");
	    mobilenumber=sc.nextLong();
		System.out.println("Enter Pick Up address: ");
		address=sc.next();
		System.out.println("Enter pincode");
		pincode=sc.nextLong();
		
		if(pincode==100)
		{
			cnumber="MH100";
			
	    }
		else if(pincode==200)
		{
			cnumber="MH200";
			
		}
		else if(pincode==300)
		{
			cnumber="MH300";
			
		}
		else
		{
			cnumber=null;
			status="Not Accepted";
			System.out.println("Your Cab Number is"+cnumber);
			System.out.println("Status"+status);
		}
		bean.setUname(uname);
		bean.setPhoneNumber(mobilenumber);
		bean.setAddress(address);
		bean.setPinCode(pincode);
		bean.setStatus(status);
		bean.setCabNumber(cnumber);
	    status="accepted";
		System.out.println("Your Cab Number is"+cnumber);
		System.out.println("Status"+status);
	    return bean;
	}
	
}
